package chain_of_responsibility.clase;

import java.util.HashMap;
import java.util.Map;

public class FacadeFiltrare {
    private static Map<String, Filtrare> mapFilter = new HashMap<>();
}
